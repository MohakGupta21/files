<?php
     $server='localhost';
     $username='root';
     $password='';
 
     $conn=mysqli_connect($server,$username,$password,'test');
     if(!$conn){
         die("Connection failed due to".mysqli_connect_error());
     }
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQs</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="style-accordion.css">

</head>

<body>
    <h1>Frequently Asked Questions</h1>
    <p id="below-heading">We are constantly trying to simplify the ABSLI DigiShield Plan!</p>
    <div class="accordion">
        <div class="accordion-item">
            <h3 class="accordion-header" id="abc">
                <?php 
                    $sql1_q = "select question from questions where id=1";
                    if ($result = mysqli_query($conn, $sql1_q)) {

                        $row=mysqli_fetch_row($result);
                        echo $row[0];
                        // Free result set
                        mysqli_free_result($result);
                      }
                    // echo $sql1_q;
                ?><i class="arrow-down"></i></h3>
            <div class="data">
                <p class="data-content">
                    <?php 
                        $sql1_a = "select answer from questions where id=1";
                        if ($result = mysqli_query($conn, $sql1_a)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>
                </p>
            </div>
        </div>
        <div class="accordion-item">
            <h3 class="accordion-header">
                    <?php 
                        $sql2_q = "select question from questions where id=2";
                        if ($result = mysqli_query($conn, $sql2_q)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];                            
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>
                    <i class="arrow-down"></i></h3>
            <div class="data">
                <p class="data-content">
                    <?php 
                        $sql2_a = "select answer from questions where id=2";
                        if ($result = mysqli_query($conn, $sql2_a)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>                   
                </p>
            </div>
        </div>
        <div class="accordion-item">
            <h3 class="accordion-header">                    
                    <?php 
                        $sql3_q = "select question from questions where id=3";
                        if ($result = mysqli_query($conn, $sql3_q)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?><i class="arrow-down"></i>
            </h3>
            <div class="data">
                <p class="data-content">
                    <?php 
                        $sql3_a = "select answer from questions where id=3";
                        if ($result = mysqli_query($conn, $sql3_a)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>  
                </p>
            </div>
        </div>
        <div class="accordion-item">
            <h3 class="accordion-header">
                    <?php 
                        $sql4_q = "select question from questions where id=4";
                        if ($result = mysqli_query($conn, $sql4_q)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>
                <i class="arrow-down"></i></h3>
            <div class="data">
                <p class="data-content">
                    <?php 
                        $sql4_a = "select answer from questions where id=4";
                        if ($result = mysqli_query($conn, $sql4_a)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>  
                </p>
            </div>
        </div>
        <div class="accordion-item">
            <h3 class="accordion-header">
                    <?php 
                        $sql5_q = "select question from questions where id=5";
                        if ($result = mysqli_query($conn, $sql5_q)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>
                <i class="arrow-down"></i></h3>
            <div class="data">
                <p class="data-content">
                    <?php 
                        $sql5_a = "select answer from questions where id=5";
                        if ($result = mysqli_query($conn, $sql5_a)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>  
                </p>
            </div>
        </div>
        <div class="accordion-item hide">
            <h3 class="accordion-header">
                    <?php 
                        $sql6_q = "select question from questions where id=6";
                        if ($result = mysqli_query($conn, $sql6_q)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>
                <i class="arrow-down"></i></h3>
            <div class="data">
                <p class="data-content">
                    <?php 
                        $sql6_a = "select answer from questions where id=6";
                        if ($result = mysqli_query($conn, $sql6_a)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>  
                </p>
            </div>
        </div>
        <div class="accordion-item hide">
            <h3 class="accordion-header">
                    <?php 
                        $sql7_q = "select question from questions where id=7";
                        if ($result = mysqli_query($conn, $sql7_q)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];         
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>
                <i class="arrow-down"></i></h3>
            <div class="data">
                <p class="data-content">
                    <?php 
                        $sql7_a = "select answer from questions where id=7";
                        if ($result = mysqli_query($conn, $sql7_a)) {

                            $row=mysqli_fetch_row($result);
                            echo $row[0];         
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>  
                </p>
            </div>
        </div>
        <div class="accordion-item hide">
            <h3 class="accordion-header">
                    <?php 
                        $sql8_q = "select question from questions where id=8";
                        if ($result = mysqli_query($conn, $sql8_q)) {
                            
                            $row=mysqli_fetch_row($result);
                            echo $row[0];         
                            // Free result set
                            mysqli_free_result($result);
                          }
                    ?>
                <i class="arrow-down"></i></h3>
            <div class="data">
                <p class="data-content">
                    <?php 
                        $sql8_a = "select answer from questions where id=8";
                        if ($result = mysqli_query($conn, $sql8_a)) {
                           
                            $row=mysqli_fetch_row($result);
                            echo $row[0];         
                            // Free result set
                            mysqli_free_result($result);
                          }
                        mysqli_close($conn);
                    ?>  
                </p>
            </div>
        </div>
    </div>
    <br>
    <span id="showAll">Show All</span>

    <script src="accordion.js"></script>

</body>

</html>